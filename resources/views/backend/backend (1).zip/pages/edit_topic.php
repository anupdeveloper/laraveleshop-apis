<style>
.bootstrap-tagsinput .tag {
    margin-right: 2px;
    color: white;
    background-color: #5369f8;
    margin: 1px 2px;
    border-radius: 2px;
    padding: 0 5px;
}
</style>
<div class="content-page">
        <div class="content">
            
            <!-- Start Content-->
            <div class="container-fluid">
                <div class="row page-title">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="float-right mt-1">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?=base_url('admin/calendar-details').'/'.$calendar_id?>">Calendar Details</a></li>
                                <li class="breadcrumb-item"><a href="<?=base_url('admin/topics').'/'.$calendar_id.'/'.$program_id?>">Topics</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?=$pagetitle?></li>
                            
                            </ol>
                        </nav>
                        <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                    </div>
                </div>
                <?php
                    if(isset($validation))
                    echo '<div class="alert alert-danger">'.$validation.'</div>';
                ?>
                <form action="<?=base_url('admin/save_topic')?>" method="POST">
                    
                <!--input type="hidden" name="calendar_id" value="<?=$calendar_id?>" />
                <input type="hidden" name="program_id" value="<?=$program_id?>" /-->
                <input type="hidden" id="topic_id" value="<?php if(isset($topic['id'])) echo $topic['id'];?>" name="topic_id" >
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="row">
                                            <label for="inputEmail" class="col-sm-6 col-form-label">Select Calendar</label>
                                            <div class="col-sm-6">
                                                <select class="form-control" id="calendar" name="calendar">
                                                    <option value="">Select Calendar</option>
                                                    <?php
                                                        foreach($calendars as $row){
                                                    ?>
                                                        <option <?php if($topic['calendar_id'] == $row['id']){?> selected <?php }?> value="<?=$row['id']?>">Calendar <?=$row['id']?></option>
                                                    <?php
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="row">
                                            <label for="inputEmail" class="col-sm-4 col-form-label">Select Program</label>
                                            <div class="col-sm-8">
                                                <select class="form-control" id="program" name="program">
                                                    <option value="">Select Program</option>
                                                    <?php
                                                        foreach($programs as $row){
                                                    ?>
                                                        <option <?php if($topic['program_id'] == $row['id']){?> selected <?php }?> value="<?=$row['id']?>"><?=$row['program_name']?></option>
                                                    <?php
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="row">
                                            <label for="inputEmail" class="col-sm-4 col-form-label">Add Speakers</label>
                                            <div class="col-sm-8">
                                                <select class="form-control wide" data-plugin="customselect" multiple id="speaker" name="speaker[]">
                                                    <option value="">Select Speaker</option>
                                                    <?php
                                                        foreach($speakers as $row){
                                                    ?>
                                                        <option  <?php if(in_array($row['id'],explode(',',$topic['speakers_id']))) echo "selected" ?>  value="<?=$row['id']?>"><?=$row['fname'].' '.$row['lname']?></option>
                                                    <?php
                                                        }
                                                    ?>
                                                </select>
                                                <!--div class="example example_multivalue">
                                                    <div class="bs-example">
                                                        <select multiple data-role="tagsinput" multiple id="speaker" name="speaker[]">
                                                            
                                                            <?php
                                                                $speakers = explode(',',$topic['speakers_ids']);
                                                                foreach($speakers as $row){
                                                            ?>
                                                                <option  value="<?=$row?>"><?=$row?></option>
                                                            <?php
                                                                }
                                                            ?> 
                                                            
                                                        </select>
                                                    </div>
                                                </div-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>    
                        <div class="form-group row">
                            <label for="inputEmail" class="col-sm-2 col-form-label">Topic Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="topic_name" value="<?php if(isset($topic['topic_name'])) echo $topic['topic_name'];?>" name="topic_name" placeholder="Topic Name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPassword" class="col-sm-2 col-form-label">Description</label>
                            <div class="col-sm-10">
                                <!--input type="text" class="form-control" id="description" name="description" placeholder="Description"-->
                                <textarea class="form-control" rows="7" id="t_description" name="description"><?php if(isset($topic['t_description'])) echo $topic['t_description'];?></textarea>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="inputPassword" class="col-sm-2 col-form-label">Schedule Date</label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" value="<?php if(isset($topic['schedule_date'])) echo $topic['schedule_date']?>" name="schedule_date" id="date" placeholder="Schedule Date">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPassword" class="col-sm-2 col-form-label">Schedule Time</label>
                            <div class="col-sm-10">
                                <input type="time" class="form-control" value="<?php if(isset($topic['schedule_time'])) echo $topic['schedule_time']?>" name="schedule_time" id="time" placeholder="Schedule Time">
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <div class="col-sm-10 offset-sm-2">
                                <button type="submit" class="btn btn-primary">Update Topic</button>
                            </div>
                        </div>
                    
                </form>
            </div>
        </div>
</div>
 
               
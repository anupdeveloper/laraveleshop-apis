<div class="content-page">
        <div class="content">
            
            <!-- Start Content-->
            <div class="container-fluid">
                <div class="row page-title">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="float-right mt-1">
                            <ol class="breadcrumb">
                                
                                <li class="breadcrumb-item"><a href="#"><?=$pagetitle?></a></li>
                            </ol>
                        </nav>
                        <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                    </div>
                </div>
                                <?php
                                    if(isset($validation))
                                    echo '<div class="alert alert-danger">'.$validation.'</div>';
                                ?>
                                <?php
                                    if(session()->getFlashdata('message'))
                                    echo '<div class="alert alert-success">'.session()->getFlashdata('message').'</div>';
                                ?>

                                <form action="<?=base_url('admin/save_settings')?>" method="POST"  enctype="multipart/form-data">
                                    
                                        <input type="hidden" id="user_id" value="<?php if(session()->get('user_logged_data')['id']) echo session()->get('user_logged_data')['id'];?>" name="user_id" >
                                        
                                        <div class="form-group row">
                                            <label for="inputEmail" class="col-sm-2 col-form-label">New Password</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" id="old_password" value="<?php  ?>" name="password" placeholder="Password">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Confirm Password</label>
                                            <div class="col-sm-10">
                                            <input type="password" class="form-control" id="password" value="<?php  ?>" name="con_password" placeholder="Confirm Password">
                                                
                                            </div>
                                        </div>

                                        
                                        <div class="form-group row">
                                            <div class="col-sm-10 offset-sm-2">
                                                <button type="submit" class="btn btn-primary">Update Password</button>
                                            </div>
                                        </div>
                                    
                                </form>
                                </div>
        </div>
</div>
 
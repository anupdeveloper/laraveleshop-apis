<div class="content-page">
        <div class="content">
            
            <!-- Start Content-->
            <div class="container-fluid">
                <div class="row page-title">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="float-right mt-1">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?=base_url('admin/calendar-details').'/'.$calendar_id?>">Calendar Details</a></li>
                                <li class="breadcrumb-item"><a href="#"><?=$pagetitle?></a></li>
                            </ol>
                        </nav>
                        <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                    </div>
                </div>
                                <?php
                                    if(isset($validation))
                                    echo '<div class="alert alert-danger">'.$validation.'</div>';
                                ?>

                                <form action="<?=base_url('admin/save_program')?>" method="POST">
                                    
                                        <input type="hidden" id="program_id" value="<?php if(isset($program['id'])) echo $program['id'];?>" name="program_id" >
                                        <input type="hidden" id="calendar_id" value="<?php if(isset($program['calendar_id'])) echo $program['calendar_id'];?>" name="calendar_id" >
                                        <div class="form-group row">
                                            <label for="inputEmail" class="col-sm-2 col-form-label">Program Name</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="program_name" value="<?php if(isset($program['program_name'])) echo $program['program_name'];?>" name="program_name" placeholder="Program Name">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Description</label>
                                            <div class="col-sm-10">
                                                <!--input type="text" class="form-control" id="description" name="description" placeholder="Description"-->
                                                <textarea class="form-control" rows="7" id="description" name="description"><?php if(isset($program['description'])) echo $program['description'];?></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Schedule Date</label>
                                            <div class="col-sm-10">
                                                <input type="date" class="form-control" value="<?php if(isset($program['schedule_date'])) echo $program['schedule_date']?>" name="schedule_date" id="date" placeholder="Schedule Date">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Schedule Time</label>
                                            <div class="col-sm-10">
                                                <input type="time" class="form-control" value="<?php if(isset($program['schedule_time'])) echo $program['schedule_time']?>" name="schedule_time" id="time" placeholder="Schedule Time">
                                            </div>
                                        </div>


                                       
                                        <div class="form-group row">
                                            <div class="col-sm-10 offset-sm-2">
                                                <button type="submit" class="btn btn-primary">Update Program</button>
                                            </div>
                                        </div>
                                    
                                </form>
                                </div>
        </div>
</div>
 
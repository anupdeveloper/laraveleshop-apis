
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4"><?=$pagetitle?></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"><?=$pagetitle?></li>
                        </ol>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <a class="btn btn-primary pullright small-btn" href="<?=base_url('admin/add_event')?>" >Add New</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Event Name</th>
                                                <th>Program</th>
                                                <th>Topic</th>
                                                <th>Speakers</th>
                                                
                                                <th>Scheduled On</th>
                                                <th>Users</th>
                                               
                                                <th width="10%">Action</th>
                                                
                                            </tr>
                                        </thead>
                                        
                                        <!--tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>Title</th>
                                                <th>Description</th>
                                                <th>Created At</th>
                                                <th>Attended</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                        </tfoot-->
                                        <tbody>
                                        <?php
                                        $i=1;
                                            foreach($programs as $row){
                                        ?>
                                            <tr>
                                                <td><?=$i++;?></td>
                                                <td><?=$row['event_name']?></td>
                                                <td><?=$row['program_name']?></td>
                                                <td><?=$row['topic_name']?></td>
                                                
                                                <td>56</td>
                                                
                                                <td><?=date('l,d F Y',strtotime($row['schedule_date']))?> - <?=date('H:i',strtotime($row['schedule_time']))?></td>
                                               
                                                <td><?=get_users_by_program_id($row['id'])?></td>
                                                <td class="actions">
                                                    <a class="btn btn-primary small-btn" href="#" >Edit</a>
                                                    <a class="btn btn-danger small-btn"  href="#" >Delete</a>

                                                </td>
                                            </tr>
                                        <?php
                                            }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
               
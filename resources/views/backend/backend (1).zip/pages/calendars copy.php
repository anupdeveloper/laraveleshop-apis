<div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        <div class="row page-title">
                            <div class="col-md-12">
                                <nav aria-label="breadcrumb" class="float-right mt-1">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#">Shreyu</a></li>
                                        <li class="breadcrumb-item"><a href="#"><?=$pagetitle?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?=$pagetitle?></li>
                                    </ol>
                                </nav>
                                <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                                <a class="btn btn-primary pullright small-btn" onclick="add_calendar();" href="javascript:void(0);" >Add New</a>
                            </div>
                        </div>

                      
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title mt-0 mb-1"><?=$pagetitle?></h4>
                                    
                                        <?php
                                        $i=1;
                                            foreach($calendars as $row){
                                        ?>
                                        <div class="item">
                                            <div class="calender-item">
                                                <div class="sb-nav-link-icon">
                                                    <a href="<?='programs/'.$row['id']?>"><i class="fas fa-calendar-alt"></i></a>
                                                    
                                                </div>
                                                
                                            </div>
                                            <h3 class="title">Calendar <?=$row['id']?></h3>
                                            <a class="view-link" href="<?=$row['calendar_link']?>">View Calendar</a>
                                            Intregation 
                                            <div class="code-script">
                                            <xmp>
                                                <iframe id="myframe" width="100%" height="700px" sandbox="allow-scripts allow-top-navigation"></iframe>
                                               <script>
                                                var url = "<?=base_url()?>/embededcalendar/<?=$row['id']?>",
                                                    frame = document.getElementById("myframe"),
                                                    listener;
                                                listener = window.addEventListener("beforeunload", function(e) {
                                                    e.preventDefault();
                                                    e.stopImmediatePropagation();
                                                    // The iframe tried to bust out!
                                                    window.removeEventListener("beforeunload", listener);
                                                    return "This is unavoidable, you cannot shortcut a " +
                                                            "navigation attempt without prompting the user";
                                                });
                                                frame.src = url;
                                               </script>
                                              </xmp>
                                            </div>
                                           
                                        </div>
                                        <?php
                                            }
                                        ?>
                                       
                                       </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div>
                        <!-- end row-->


                        
                       
                    </div> <!-- container-fluid -->

                </div> <!-- content -->
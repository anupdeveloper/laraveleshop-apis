<div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        <div class="row page-title">
                            <div class="col-md-12">
                                <nav aria-label="breadcrumb" class="float-right mt-1">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#">Shreyu</a></li>
                                        <li class="breadcrumb-item"><a href="#"><?=$pagetitle?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?=$pagetitle?></li>
                                    </ol>
                                </nav>
                                <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                            </div>
                        </div>

                      
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title mt-0 mb-1"><?=$pagetitle?></h4>
                                        <?php
                                            if(isset($calendar_id)){
                                            ?>
                                                <a class="btn btn-primary pullright small-btn" href="<?=base_url('admin/add_program').'/'.$calendar_id?>" >Add New</a>
                                            <?php
                                            }else{
                                                ?>
                                                <a class="btn btn-primary pullright small-btn" href="<?=base_url('admin/add_program')?>" >Add New</a>
                                                <?php
                                            }
                                        ?>
                                        <p class="sub-header">
                                            
                                            <?php
                                                    if(session()->getFlashdata('message'))
                                                    echo '<div class="alert alert-success">'.session()->getFlashdata('message').'</div>';
                                            ?>
                                        </p>

                                         <!-- datatable-buttons -->           
                                        <table id="basic-datatable" class="table table-striped dt-responsive nowrap">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Title</th>
                                                    <th>Topics</th>
                                                    
                                                    <th>Attended</th>
                                                    <th>Upcoming Event</th>
                                                    <th>Register Link</th>
                                                    <th>Created At</th>
                                                    <th width="10%">Action</th>
                                                </tr>
                                            </thead>
                                        
                                        
                                            <tbody>
                                               <?php
                                                $i=1;
                                                    foreach($programs as $row){
                                                ?>
                                                    <tr>
                                                        <td><?=$i++;?></td>
                                                        <td><?=$row['program_name']?></td>
                                                        <td><?=get_topics($row['id'],'program_id')?></td>
                                                        
                                                        <td><?=get_users($row['id'],'program_id')?></td>
                                                        
                                                        <td>--</td>
                                                        <td><a class="btn btn-primary small-btn" target="_blank" href="<?=base_url('program'.$row['id'].'/register');?>" >Register Link</a></td>
                                                        <td>
                                                        <?=$row['created_at']?>   
                                                        </td>
                                                        <td class="actions">
                                                            <a class="btn btn-primary small-btn" href="<?=base_url('admin/edit_program/'.$row['id'])?>" >Edit</a>
                                                            <a class="btn btn-danger small-btn"  href="#" >Delete</a>

                                                        </td>
                                                    </tr>
                                                <?php
                                                    }
                                                ?>
                                                
                                            </tbody>
                                        </table>
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div>
                        <!-- end row-->


                        
                       
                    </div> <!-- container-fluid -->

                </div> <!-- content -->
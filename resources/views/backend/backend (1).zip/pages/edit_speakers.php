<div class="content-page">
        <div class="content">
            
            <!-- Start Content-->
            <div class="container-fluid">
                <div class="row page-title">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="float-right mt-1">
                            <ol class="breadcrumb">
                                
                                <li class="breadcrumb-item"><a href="#"><?=$pagetitle?></a></li>
                            </ol>
                        </nav>
                        <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                    </div>
                </div>
                                <?php
                                    if(isset($validation))
                                    echo '<div class="alert alert-danger">'.$validation.'</div>';
                                ?>
                                <?php
                                    if(session()->getFlashdata('message'))
                                    echo '<div class="alert alert-success">'.session()->getFlashdata('message').'</div>';
                                ?>

                                <form action="<?=base_url('admin/save_user')?>" method="POST"  enctype="multipart/form-data">
                                    
                                        <input type="hidden" id="user_id" value="<?php if(isset($users['id'])) echo $users['id'];?>" name="user_id" >
                                        
                                        <div class="form-group row">
                                            <label for="inputEmail" class="col-sm-2 col-form-label">First Name</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="fname" value="<?php  if(isset($_POST['fname'])){ echo $_POST['fname']; }else   if(isset($users['fname'])) echo  $users['fname'] ;?>" name="fname" placeholder="First Name">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Last Name</label>
                                            <div class="col-sm-10">
                                            <input type="text" class="form-control" id="lname" value="<?php  if(isset($_POST['lname'])){ echo $_POST['lname']; }else if(isset($users['lname'])) echo $users['lname'] ;?>" name="lname" placeholder="Last Name">
                                                
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Email</label>
                                            <div class="col-sm-10">
                                            <input type="text" class="form-control" id="email" value="<?php  if(isset($_POST['email'])){ echo $_POST['email']; }else if(isset($users['email'])) echo $users['email'] ;?>" name="email" placeholder="Email">
                                                
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Upload Profile</label>
                                            <div class="col-sm-10">
                                                <input type="file" class="form-control"  name="profile_pic" id="profile_pic" >
                                                <?php
                                                    if(isset($users['profile_pic'])){
                                                ?>
                                                <img src="<?=base_url()?>/public/images/<?=$users['profile_pic']?>" />
                                                 <?php
                                                    }
                                                 ?>
                                            </div>
                                        </div>

                                        <input type="hidden" name="user_role" value="4" />
                                       
                                        <div class="form-group row">
                                            <div class="col-sm-10 offset-sm-2">
                                                <button type="submit" class="btn btn-primary"><?php if(isset($users['id'])) echo 'Update User'; else echo 'Add Speaker';?></button>
                                            </div>
                                        </div>
                                    
                                </form>
                                </div>
        </div>
</div>
 
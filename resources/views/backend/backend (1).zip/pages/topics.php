<div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        <div class="row page-title">
                            <div class="col-md-12">
                                <nav aria-label="breadcrumb" class="float-right mt-1">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?=base_url('admin/calendar-details').'/'.$calendar_id?>">Calendar Details</a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?=$pagetitle?></li>
                                    </ol>
                                </nav>
                                <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="header-title mt-0 mb-1"><?=$pagetitle?></h4>
                                        <?php
                                            if(isset($calendar_id)){
                                            ?>
                                                <a class="btn btn-primary pullright small-btn" href="<?=base_url('admin/add_topic').'/'.$calendar_id.'/'.$program_id?>" >Add New</a>
                                            <?php
                                            }else{
                                                ?>
                                                <a class="btn btn-primary pullright small-btn" href="<?=base_url('admin/add_topic')?>" >Add New</a>
                                                <?php
                                            }
                                        ?>
                                        <p class="sub-header">
                                            
                                            <?php
                                                    if(session()->getFlashdata('message'))
                                                    echo '<div class="alert alert-success">'.session()->getFlashdata('message').'</div>';
                                            ?>
                                        </p>
                                        <table id="basic-datatable" class="table table-striped dt-responsive nowrap">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Topic</th>
                                                <th>Users</th>
                                                <th>Speakers</th>
                                                <th>Register Link</th>
                                                <th>Zoom Link</th>
                                                <th>Scheduled On</th>
                                                <!--th>Description</th-->
                                                <th>Program</th>
                                                
                                                
                                                
                                                <th width="10%">Action</th>
                                                
                                            </tr>
                                        </thead>
                                        
                                        <!--tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th>Title</th>
                                                <th>Description</th>
                                                <th>Created At</th>
                                                <th>Attended</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                        </tfoot-->
                                        <tbody>
                                        <?php
                                        $i=1;
                                            foreach($topics as $row){
                                                $sp_cout = 0;
                                                if(!empty($row['speakers_id']))
                                                $sp_cout = count(explode(',',$row['speakers_id']));
                                        ?>
                                            <tr>
                                                <td><?=$i++;?></td>
                                                <td><?=$row['topic_name']?></td>
                                                <!--td><?=$row['t_description']?></td-->
                                                <td><span class="badge badge-primary badge-pill"><?=get_users($row['id'],'id')?></span></td>
                                                <td><span class="badge badge-info badge-pill"><?=$sp_cout;?></span></td>
                                                <td><a class="btn btn-primary small-btn" target="_blank" href="<?=base_url('program'.$row['program_id'].'/topic'.$row['id'].'/register');?>" >Register Link</a></td>
                                                <td><a class="btn btn-primary small-btn" target="_blank" href="<?=$row['zoom_join_link']?>" >Zoom Link</a></td>
                                                <td><?=date('m/d/Y',strtotime($row['schedule_date']))?></td>
                                                <td><?=$row['program_name']?></td>
                                                
                                                
                                                <td class="actions">
                                                    <a class="btn btn-primary small-btn" href="<?=base_url('admin/edit_topic/'.$row['id'])?>" >Edit</a>
                                                    <a class="btn btn-danger small-btn"  href="#" >Delete</a>

                                                </td>
                                            </tr>
                                        <?php
                                            }
                                        ?>
                                        </tbody>
                                    </table>
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div>
                        <!-- end row-->


                        
                       
                    </div> <!-- container-fluid -->

</div> <!-- content -->
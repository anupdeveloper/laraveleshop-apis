<div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        <div class="row page-title">
                            <div class="col-md-12">
                                <nav aria-label="breadcrumb" class="float-right mt-1">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#"><?=$pagetitle?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?=$pagetitle?></li>
                                    </ol>
                                </nav>
                                <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                                <!--a class="btn btn-primary pullright small-btn" onclick="add_calendar();" href="javascript:void(0);" >Add New</a-->
                                <button data-toggle="modal" data-target="#event-modal" class="btn btn-primary mt-2 mr-1" id="btn-new-event"><i
                                                        class="uil-plus-circle"></i> Create New Calendar</button>
                            
                                <!-- modals -->
                                <!-- Add New Event MODAL -->
                                <div class="modal fade" id="event-modal" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header py-3 px-4 border-bottom-0 d-block">
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-hidden="true">&times;</button>
                                                <h5 class="modal-title" id="modal-title">Calendar Details</h5>
                                            </div>
                                            <div class="modal-body p-4">
                                                <form class="needs-validation" name="calendar-form" id="form-calendar" novalidate method="POST">
                                                    <input type="hidden" name="calendar_id" id="calendar_id" value="" />
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label class="control-label">Calendar Name</label>
                                                                <input class="form-control" placeholder="Calendar Name"
                                                                    type="text" name="calendar_name" id="calendar_name" required />
                                                                <div class="invalid-feedback">Please provide a valid Calendar name</div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label class="control-label">Description</label>
                                                                <textarea name="description" id="description" rows="5" class="form-control" placeholder="Description"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row mt-2">
                                                        <div class="col-6">
                                                        <button type="button" class="btn btn-danger mr-1" data-dismiss="modal">Close</button>
                                                        </div>
                                                        <div class="col-6 text-right">
                                                            
                                                            <button type="submit" class="btn btn-success" id="btn-save-event">Save</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div> <!-- end modal-content-->
                                    </div> <!-- end modal dialog-->
                                </div>
                                <!-- end modal-->
                            </div>
                        </div>

                      
                        <div class="row">

                            <?php
                            $i=1;
                                foreach($calendars as $row){
                                    $count_topics = get_topics($row['id'],'calendar_id');
                            ?>
                                <div class="col-xl-4 col-lg-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="badge badge-info float-right "><a class="btn-curser"    onclick="edit_calendar(<?=$row['id']?>)">Edit</a></div>
                                            <div class="badge badge-danger float-right "> <a class="btn-curser"    onclick="delete_table(<?=$row['id']?>,'calendars')">Delete</a></div>
                                            <p class="text-success text-uppercase font-size-12 mb-2">Calendar</p>
                                            <h5><a href="<?=base_url('admin/calendar-details/'.$row['id'])?>" class="text-dark"><?=$row['calendar_name']?></a></h5>
                                            <p class="text-muted mb-4"><?=$row['description']?></p>
                                            
                                            <div>
                                                <?php
                                                $get_speakers = get_speakers_imgs($row['id'],'calendar_id');
                                                foreach($get_speakers as $img){
                                                ?>
                                                <a href="javascript: void(0);">
                                                    <img src="<?=base_url()?>/public/images/<?=$img?>" alt="" class="avatar-sm m-1 rounded-circle">
                                                </a>
                                                <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <div class="card-body border-top">
                                            <div class="row align-items-center">
                                                <div class="col-sm-auto">
                                                    <ul class="list-inline mb-0">
                                                        <li class="list-inline-item pr-2">
                                                            <a href="#" class="text-muted d-inline-block">
                                                                Topics: <span class="badge badge-primary badge-pill"><?=get_topics($row['id'],'calendar_id')?></span>
                                                            </a>
                                                        </li>
                                                        <li class="list-inline-item pr-2">
                                                            <a href="#" class="text-muted d-inline-block">
                                                                Users: <span class="badge badge-info badge-pill"><?=get_users($row['id'],'calendar_id')?></span>
                                                            </a>
                                                        </li>
                                                        
                                                    </ul>
                                                </div>
                                                <div class="col offset-sm-1">
                                                        <?php
                                                            if($count_topics>0){
                                                        ?>
                                                        <a class="btn btn-primary small-btn" target="_blank" href="<?=$row['calendar_link'];?>" >View Calendar</a></td>
                                                        <?php
                                                            }else{
                                                                echo 'No topic yet';
                                                            }
                                                        ?>
                                                    <!--div class="progress mt-4 mt-sm-0" style="height: 5px;"
                                                        data-toggle="tooltip" data-placement="top" title=""
                                                        data-original-title="100% completed">
                                                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%;"
                                                            aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end card -->
                                </div>
                            <?php
                                }
                            ?>
                            
                            
                        </div>
                        <!-- end row -->

                        <!--div class="row mb-3 mt-2">
                            <div class="col-12">
                                <div class="text-center">
                                    <a href="javascript:void(0);" class="btn btn-white">
                                        <i data-feather="loader" class="icon-dual icon-xs mr-2"></i>
                                        Load more
                                    </a>
                                </div>
                            </div> 
                        </div-->
                        <!-- end row-->


                        
                       
                    </div> <!-- container-fluid -->

                </div> <!-- content -->
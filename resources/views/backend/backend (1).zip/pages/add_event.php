
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4"><?=$pagetitle?></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"><?=$pagetitle?></li>
                        </ol>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <a class="btn btn-primary small-btn" href="<?=base_url('admin/events')?>" >List</a>
                            </div>
                            <div class="card-body">
                                <?php
                                    if(isset($validation))
                                    echo '<div class="alert alert-danger">'.$validation.'</div>';
                                ?>
                                <form action="<?=base_url('admin/save_event')?>" method="post">
                                    
                                        <div class="form-group row">
                                            <label for="inputEmail" class="col-sm-2 col-form-label">Event Name</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" id="event_name" value="<?php if(isset($_POST['event_name'])) echo $_POST['event_name'];?>" name="event_name" placeholder="Event Name">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputEmail" class="col-sm-2 col-form-label">Select Program</label>
                                            <div class="col-sm-10">
                                                <select id="program_id" class="form-control"  name="program_id">
                                                    <option  value="">Select One</option>
                                                    <?php
                                                        foreach($programs as $row){
                                                    ?>
                                                    <option <?php if(isset($_POST['program_id']))if($_POST['program_id']== $row['id']) echo 'selected'; ?>  value="<?=$row['id']?>"><?=$row['program_name']?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Select Topic</label>
                                            <div class="col-sm-10">
                                                <select id="topic_ids" class="form-control"  name="topic_ids">
                                                    <option  value="">Select One</option>
                                                    <?php
                                                        foreach($topics as $row){
                                                    ?>
                                                    <option <?php if(isset($_POST['topic_ids']))if($_POST['topic_ids']== $row['id']) echo 'selected'; ?>  value="<?=$row['id']?>"><?=$row['topic_name']?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="inputEmail" class="col-sm-2 col-form-label">Select Speakers</label>
                                            <div class="col-sm-10">
                                                <select id="topic_id" class="form-control" multiple  name="speaker_ids[]">
                                                    <option  value="">Select One</option>
                                                    <?php
                                                        foreach($speakers as $row){
                                                    ?>
                                                    <option <?php if(isset($_POST['speaker_ids']))if($_POST['speaker_ids']== $row['id']) echo 'selected'; ?>  value="<?=$row['id']?>"><?=$row['fname'].' '.$row['lname']?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Schedule Date</label>
                                            <div class="col-sm-10">
                                                <input type="date" class="form-control" value="<?php if(isset($_POST['schedule_date'])) echo $_POST['schedule_date']?>" name="schedule_date" id="date" placeholder="Schedule Date">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputPassword" class="col-sm-2 col-form-label">Schedule Time</label>
                                            <div class="col-sm-10">
                                                <input type="time" class="form-control" value="<?php if(isset($_POST['schedule_time'])) echo $_POST['schedule_time']?>" name="schedule_time" id="time" placeholder="Schedule Time">
                                            </div>
                                        </div>


                                       
                                        <div class="form-group row">
                                            <div class="col-sm-10 offset-sm-2">
                                                <button type="submit" class="btn btn-primary">Save Event</button>
                                            </div>
                                        </div>
                                    
                                </form>
                                </div>
                            </div>
                    </div>
                </main>
               
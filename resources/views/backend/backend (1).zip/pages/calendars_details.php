<div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        <div class="row page-title">
                            <div class="col-md-12">
                                <nav aria-label="breadcrumb" class="float-right mt-1">
                                    <ol class="breadcrumb">
                                        
                                        <li class="breadcrumb-item"><a href="<?=base_url('admin/calendars')?>">Calendar</a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?=$pagetitle?></li>
                                    </ol>
                                </nav>
                                <h4 class="mb-1 mt-0"><?=$pagetitle?></h4>
                               
                            </div>
                        </div>

                      
                        <div class="row">
                        <!--div class="col-lg-3">
                            <div class="card">
                                <div class="card-body">
                                    <div class="text-center mt-3">
                                        <h5 class="mt-2 mb-0">Calendar <?=$calendar_id?></h5>
                                       
                                       
                                        <img src="<?=ASSETS_URL?>/admin/assets/images/cal.png" class="mr-4 align-self-center img-fluid " alt="cal">

                                        <a href="<?=$calendar_details['calendar_link']?>" class="btn btn-primary btn-sm mr-1">View</a>
                                        
                                    </div>

                                    
                                </div>
                            </div>
                            

                        </div-->

                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <ul class="nav nav-pills navtab-bg nav-justified" id="pills-tab" role="tablist">
                                        <!--li class="nav-item">
                                            <a class="nav-link active" id="pills-activity-tab" data-toggle="pill"
                                                href="#pills-activity" role="tab" aria-controls="pills-activity"
                                                aria-selected="true">
                                                Activity
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="pills-messages-tab" data-toggle="pill"
                                                href="#pills-messages" role="tab" aria-controls="pills-messages"
                                                aria-selected="false">
                                                Messages
                                            </a>
                                        </li-->
                                        <li class="nav-item">
                                            <a class="nav-link active" id="pills-projects-tab" data-toggle="pill"
                                                href="#pills-projects" role="tab" aria-controls="pills-projects"
                                                aria-selected="false">
                                                Programs
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="pills-tasks-tab" data-toggle="pill"
                                                href="#pills-tasks" role="tab" aria-controls="pills-tasks"
                                                aria-selected="false">
                                                Intregation
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="pills-files-tab" data-toggle="pill"
                                                href="#pills-files" role="tab" aria-controls="pills-files"
                                                aria-selected="false">
                                                View Calendar
                                            </a>
                                        </li>
                                    </ul>

                                    <div class="tab-content" id="pills-tabContent">
                                        

                                        <div class="tab-pane fade show active" id="pills-projects" role="tabpanel"
                                            aria-labelledby="pills-projects-tab ">
                                            <a class="btn btn-primary pullright small-btn" href="<?=base_url('admin/add_program').'/'.$calendar_id?>" >Add New</a>
                                            
                                            <h5 class="mt-3">Programs</h5>
                                            <?php
                                                    if(session()->getFlashdata('message'))
                                                    echo '<div class="alert alert-success">'.session()->getFlashdata('message').'</div>';
                                            ?>
                                            
                                            <div class="row mt-3">
                                            <table id="basic-datatable" class="table table-striped dt-responsive nowrap">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Title</th>
                                                    <th>Topics</th>
                                                    
                                                    <th>Attended</th>
                                                    <th>Upcoming Event</th>
                                                    <th>Register Link</th>
                                                    <th>Created At</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                        
                                        
                                            <tbody>
                                               <?php
                                                $i=1;
                                                    foreach($programs as $row){
                                                       $count_topics = get_topics($row['id'],'program_id');
                                                ?>
                                                    <tr>
                                                        <td><?=$i++;?></td>
                                                        <td><a href="<?=base_url('admin/topics').'/'.$calendar_id.'/'.$row['id']?>"><?=substr($row['program_name'],0,30).' ...'?></a></td>
                                                        <td><span class="badge badge-primary badge-pill"><?=$count_topics?></span></td>
                                                        
                                                        <td><span class="badge badge-info badge-pill"><?=get_users($row['id'],'program_id')?></span></td>
                                                        
                                                        <td>--</td>
                                                        <td>
                                                        <?php
                                                            if($count_topics>0){
                                                        ?>
                                                        <a class="btn btn-primary small-btn" target="_blank" href="<?=base_url('program'.$row['id'].'/register');?>" >Register Link</a></td>
                                                        <?php
                                                            }else{
                                                                echo 'No topic yet';
                                                            }
                                                        ?>
                                                        <td>
                                                        <?=$row['created_at']?>   
                                                        </td>
                                                        <td class="actions">
                                                            <a class="btn btn-primary small-btn" href="<?=base_url('admin/edit_program/'.$row['id'])?>" >Edit</a>
                                                            <a class="btn btn-danger small-btn"  href="#" >Delete</a>

                                                        </td>
                                                    </tr>
                                                <?php
                                                    }
                                                ?>
                                                
                                            </tbody>
                                        </table>
                                            </div>
                                            <!-- end row -->
                                        </div>

                                        <div class="tab-pane fade" id="pills-tasks" role="tabpanel"
                                            aria-labelledby="pills-tasks-tab">
                                            <h5 class="mt-3">Intregation</h5>

                                            <div class="card mb-0 shadow-none">
                                                <div class="card-body">
                                                    <div class="code-script">
                                                        <xmp>
                                                            <iframe id="myframe" width="100%" height="700px" sandbox="allow-scripts allow-top-navigation"></iframe>
                                                            <script>
                                                                var url = "<?=base_url()?>/embededcalendar/<?=$calendar_id?>",
                                                                    frame = document.getElementById("myframe"),
                                                                    listener;
                                                                listener = window.addEventListener("beforeunload", function(e) {
                                                                    e.preventDefault();
                                                                    e.stopImmediatePropagation();
                                                                    // The iframe tried to bust out!
                                                                    window.removeEventListener("beforeunload", listener);
                                                                    return "This is unavoidable, you cannot shortcut a " +
                                                                            "navigation attempt without prompting the user";
                                                                });
                                                                frame.src = url;
                                                            </script>
                                                        </xmp>
                                                    </div>
                                                </div> <!-- end card-body-->
                                            </div> <!-- end card -->
                                        </div>

                                        <div class="tab-pane fade" id="pills-files" role="tabpanel"
                                            aria-labelledby="pills-files-tab">
                                            

                                           
                                                <div class="text-center mt-3">
                                                    <h5 class="mt-2 mb-0">Calendar <?=$calendar_id?></h5>
                                                
                                                
                                                    <a href="<?=$calendar_details['calendar_link']?>" ><img src="<?=ASSETS_URL?>/admin/assets/images/cal.png" class="mr-4 align-self-center img-fluid " alt="cal"></a>

                                                    <a href="<?=$calendar_details['calendar_link']?>" class="btn btn-primary btn-sm mr-1">View</a>
                                                    
                                               
                                                </div>
                                           
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!-- end card -->
                        </div>
                    </div>
                        </div> <!-- end card body-->
                            </div> <!-- end card -->
                        </div><!-- end col-->
                    </div>
                    <!-- end row-->


                    
                    
                </div> <!-- container-fluid -->

            </div> <!-- content -->
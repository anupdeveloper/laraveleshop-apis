     <!-- Footer Start -->
     <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <?=date('Y')?> &copy; Calendar APP. All Rights Reserved.
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- Right Sidebar -->
        <div class="right-bar">
            <div class="rightbar-title">
                <a href="javascript:void(0);" class="right-bar-toggle float-right">
                    <i data-feather="x-circle"></i>
                </a>
                <h5 class="m-0">Customization</h5>
            </div>
    
            <div class="slimscroll-menu">
    
                <h5 class="font-size-16 pl-3 mt-4">Choose Variation</h5>
                <div class="p-3">
                    <h6>Default</h6>
                    <a href="index.html"><img src="<?=ASSETS_URL?>/admin/assets/images/layouts/vertical.jpg" alt="vertical" class="img-thumbnail demo-img" /></a>
                </div>
                <div class="px-3 py-1">
                    <h6>Top Nav</h6>
                    <a href="layouts-horizontal.html"><img src="<?=ASSETS_URL?>/admin/assets/images/layouts/horizontal.jpg" alt="horizontal" class="img-thumbnail demo-img" /></a>
                </div>
                <div class="px-3 py-1">
                    <h6>Dark Side Nav</h6>
                    <a href="layouts-dark-sidebar.html"><img src="<?=ASSETS_URL?>/admin/assets/images/layouts/vertical-dark-sidebar.jpg" alt="dark sidenav" class="img-thumbnail demo-img" /></a>
                </div>
                <div class="px-3 py-1">
                    <h6>Condensed Side Nav</h6>
                    <a href="layouts-dark-sidebar.html"><img src="<?=ASSETS_URL?>/admin/assets/images/layouts/vertical-condensed.jpg" alt="condensed" class="img-thumbnail demo-img" /></a>
                </div>
                <div class="px-3 py-1">
                    <h6>Fixed Width (Boxed)</h6>
                    <a href="layouts-boxed.html"><img src="<?=ASSETS_URL?>/admin/assets/images/layouts/boxed.jpg" alt="boxed"
                            class="img-thumbnail demo-img" /></a>
                </div>
            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- Vendor js -->
        <script src="<?=ASSETS_URL?>/admin/assets/js/vendor.min.js"></script>

        
        <!-- datatable js -->
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/dataTables.bootstrap4.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        

        <script src="<?=ASSETS_URL?>/admin/assets/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/select2/select2.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/multiselect/jquery.multi-select.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/flatpickr/flatpickr.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        

        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/buttons.print.min.js"></script>

        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/datatables/dataTables.select.min.js"></script>

        <!-- Datatables init -->
        <script src="<?=ASSETS_URL?>/admin/assets/js/pages/datatables.init.js"></script>

        <!-- optional plugins -->
        <script src="<?=ASSETS_URL?>/admin/assets/libs/moment/moment.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/apexcharts/apexcharts.min.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/libs/flatpickr/flatpickr.min.js"></script>

       
        <!-- page js -->
        <script src="<?=ASSETS_URL?>/admin/assets/js/pages/dashboard.init.js"></script>
        <script src="<?=ASSETS_URL?>/admin/assets/js/pages/form-advanced.init.js"></script>
        <!-- App js -->
        <script src="<?=ASSETS_URL?>/admin/assets/js/app.min.js"></script>

        <script src="<?=ASSETS_URL?>admin/assets/tag/bootstrap-tagsinput.min.js"></script>


    </body>
</html>

<script>

$('#form-calendar').submit(function (event) { 
    event.preventDefault();
    url = "<?=base_url('admin/add_calendar')?>";

    $.ajax({
        url : url,
        type: "POST",
        dataType: "JSON",
        data:$("#form-calendar").serialize(),
        success: function(data)
        {
            if(data.status==true){
                alert(data.msg);
                location.reload();
            }
            
            
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
        }
    });
});

function edit_calendar(ID){
    console.log(ID)
    url = "<?=base_url('admin/calendars_details_json')?>/"+ID;
    $.ajax({
        url : url,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            if(data.status==true){

                $('#calendar_id').val(data.calendar_details.id);
                $('#calendar_name').val(data.calendar_details.calendar_name);
                $('#description').val(data.calendar_details.description);
                $('#btn-save-event').text('Update');
                $('#event-modal').modal('show');
            }
            
            
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
        }
    });
}



$('#calendar').on('change',function (){
    console.log($(this).val())
    url = "<?=base_url('admin/programs_json')?>/"+ $(this).val();

    $.ajax({
        url : url,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            if(data.status==true){
                //alert(data.programs);
                $('#program').html(data.programs);
                //location.reload();
            }
            
            
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
        }
    });
});


function delete_table(id,table){

    if(confirm("Are you sure you want to delete this?")){
        url = "<?=base_url('admin/delete_table')?>/"+ id+"/"+table;

        $.ajax({
            url : url,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
                if(data.status==true){
                    //alert(data.msg);
                    location.reload();
                }
                
                
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
    }
    else{
        return false;
    }
    
}

$('#field_type').on('change',function (){
    console.log($(this).val())
    if($(this).val() == 'select' ||  $(this).val() == 'checkbox')
    $('#options').html('<textarea cols="60" class="form-control" name="option_values" id="option_values"></textarea>');
    else
    $('#options').html('');
});

$('#regsettings-form').submit(function (event) { 
    event.preventDefault();
    url = "<?=base_url('admin/update_register_settings')?>";

    $.ajax({
        url : url,
        type: "POST",
        dataType: "JSON",
        data:$("#regsettings-form").serialize(),
        success: function(data)
        {
            if(data.status==true){
                alert(data.msg);
                location.reload();
            }
            
            
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
        }
    });
});

</script>
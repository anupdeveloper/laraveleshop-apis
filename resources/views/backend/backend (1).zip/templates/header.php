<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Calendar APP - Admin & Dashboard Template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        
        <!-- plugins -->
        <link href="<?=ASSETS_URL?>/admin/assets/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/select2/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/multiselect/multi-select.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.css" rel="stylesheet" type="text/css" />
        <!-- plugin css -->
        <link href="<?=ASSETS_URL?>/admin/assets/libs/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/libs/datatables/select.bootstrap4.min.css" rel="stylesheet" type="text/css" /> 

        <!-- App css -->
        <link href="<?=ASSETS_URL?>/admin/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/css/app.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=ASSETS_URL?>/admin/assets/css/custom.css" rel="stylesheet" type="text/css" />
        
        <link rel="stylesheet" href="<?=ASSETS_URL?>/admin/assets/tag/bootstrap-tagsinput.css">
    </head>
    <body>
        <!-- Begin page -->
        <div id="wrapper">